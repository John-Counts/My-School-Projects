﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Assignment_6
{
    internal class Student
    {
        public static int Count = 0;
        private static readonly Random rnd = new Random();
        private string firstname;
        private string lastname;
        private int sID;
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public int SID { get; set; }
        public Student(string first, string last, int id)
        {
            Firstname = first;
            Lastname = last;
            SID = id;
            Count++;
            Console.WriteLine("const 1");       //to denote the constructor used, for testing
        }
        public Student(string first = "", string last = "")
        {
            Firstname = first;
            Lastname = last;
            SID = rnd.Next(1000, 9999);
            Count++;
            Console.WriteLine("const 2");
        }

    }
}
