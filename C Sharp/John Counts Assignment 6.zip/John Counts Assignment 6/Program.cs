﻿namespace John_Counts_Assignment_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("initializing...");
            Student s1 = new Student();
            s1.Firstname = "John";
            s1.Lastname = "Smith";
            s1.SID = 2560;

            Student s2 = new Student("Peter");
            Student s3 = new Student("Morgan", "Simmons");
            Student s4 = new Student("James", "Walters");
            Student s5 = new Student("Linda", "Scott", 1005);

            Console.WriteLine();
            Console.WriteLine("total students: {0}", Student.Count);
            Console.WriteLine("Students:\tName\t\t\tID\n");
            Console.WriteLine("\t\t{0} {1}\t\t{2}", s1.Firstname, s1.Lastname, s1.SID);
            Console.WriteLine("\t\t{0} {1}\t\t\t{2}", s2.Firstname, s2.Lastname, s2.SID);       //tabs are for formatting the table
            Console.WriteLine("\t\t{0} {1}\t\t{2}", s3.Firstname, s3.Lastname, s3.SID);
            Console.WriteLine("\t\t{0} {1}\t\t{2}", s4.Firstname, s4.Lastname, s4.SID);
            Console.WriteLine("\t\t{0} {1}\t\t{2}", s5.Firstname, s5.Lastname, s5.SID);

        }
    }
}
