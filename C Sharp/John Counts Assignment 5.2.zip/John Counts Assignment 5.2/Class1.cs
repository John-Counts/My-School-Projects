﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Assignment_5._2
{
    internal class Calculator
    {
        private double firstOperand;
        private double secondOperand;
        private double result;
        public double FirstOperand { get; set; }
        public double SecondOperand{ get; set; }
        public double Result
        {
            get
            {
                Addition();
                return result;
            }
        }

        public void Addition()
        {
            result = FirstOperand + SecondOperand;
        }
    }
}
