﻿namespace John_Counts_Assignment_5._2
{
    internal class CalculatorRun
    {
        static void Main(string[] args)
        {
            Console.WriteLine("this is the calculator program.");
            Console.WriteLine("Please enter the first operand below:");
            Calculator calculator = new Calculator();
            calculator.FirstOperand = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please enter the second operand below:");
            calculator.SecondOperand = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("the result of {0} + {1} is {2}", calculator.FirstOperand, calculator.SecondOperand, calculator.Result);
        }
    }
}
