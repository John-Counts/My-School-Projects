﻿using System.Numerics;

namespace John_Counts_Assignment_3
{
    internal class Calculator
    {
        public static double Addition(double x, double y)
        {
            return x + y;
        }
        public static double Subtraction(double x, double y)
        {
            return x - y;
        }
        public static double Multiplication(double x, double y)
        {
            return x * y;
        }
        public static double Division(double x, double y)
        {
            return x / y;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("please enter the first operand:");
            double op1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("please enter the operator:");
            String oper = Console.ReadLine();
            Console.WriteLine("please enter the second operand:");
            double op2 = Convert.ToDouble(Console.ReadLine());
            double result;
            switch (oper)
            {
                case "+":
                    result = Addition(op1, op2);
                    Console.WriteLine("operation: {0} {1} {2} = {3}", op1, oper, op2, result);
                    break;
                case "-":
                    result = Subtraction(op1, op2);
                    Console.WriteLine("operation: {0} {1} {2} = {3}", op1, oper, op2, result);
                    break;
                case "*":
                    result = Multiplication(op1, op2);
                    Console.WriteLine("operation: {0} {1} {2} = {3}", op1, oper, op2, result);
                    break;
                case "/":
                    result = Division(op1, op2);
                    Console.WriteLine("operation: {0} {1} {2} = {3}", op1, oper, op2, result);
                    break;
                default:
                    Console.WriteLine("you do not feel like math today.");
                    break;
            }



        }

        
    }
}
