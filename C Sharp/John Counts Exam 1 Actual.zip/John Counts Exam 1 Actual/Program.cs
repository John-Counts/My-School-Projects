﻿using System.ComponentModel.Design;
using System.Net.Http.Headers;

namespace John_Counts_Exam_1_Actual
{
    internal class MultipleChoice
    {


        public static String Answer(string prompt)
        {
            Console.WriteLine(prompt);
            return Console.ReadLine().ToUpper();
        }


        static void Main(string[] args)
        {
            Console.WriteLine("This is the testing apparatus.");
            byte att = 0;       //attempts
            string ans = "";  //answer
            double sco = 0;     //score
            bool ret = true;
            while (att < 2 & (ret = true))
            {
                sco = 0;
                att++;
                Console.WriteLine("this is attempt {0}", att);
                Console.WriteLine("1.  what is the capital of Florida?{0}A.  Orlando{0}B.  Tallahassee{0}C.  Miami{0}D.  Tampa", "\n      ");
                ans = Answer("please enter your answer: ");
                switch (ans)
                {
                    case "B":
                        sco = sco + 50.00;
                        break;
                    default:        //other cases not necessary, only one correct answer
                        break;
                }
                Console.WriteLine("2.  in what city is Disney World?{0}A.  Orlando{0}B.  Tallahassee{0}C.  Miami{0}D.  Tampa", "\n      ");
                ans = Answer("please enter your answer: ");
                switch (ans)
                {
                    case "A":
                        sco = sco + 50.00;
                        break;
                    default:
                        break;
                }
                Console.WriteLine("your grade is {0}", sco);
                if (att > 1)
                {
                    break;
                }
                else if (sco == 100)
                {
                    ret = false;
                    break;
                }
                ans = Answer("would you like to try again?");       //asks user if they would like to take the test again, if attempts are left
                if (ans == "Y")
                {
                    ret = true;
                }
                else
                {
                    ret = false;
                }




            }





        }
    }
}
