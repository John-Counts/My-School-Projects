﻿namespace John_Counts_Assignment_2
{
    internal class Receipt
    {
        static void Main(string[] args)
        {
            decimal count = 0;
            decimal amount = 0;
            decimal subtotal = 0;
            decimal total = 0;
            decimal tax = 0;


            do
            {
                Console.WriteLine("please enter an amount to add:");
                amount = Convert.ToDecimal(Console.ReadLine());
                if (amount != -1)    //does not add -1 to calculations for using sentinel value
                {


                    subtotal += amount;
                    tax = subtotal * (decimal)0.07; //have to cast .07 to decimal to do math with the two data types
                    total = tax + subtotal;
                }
                else { count--; } //decrements count to accomodate exit run of loop
                Console.WriteLine("count: {0}, subtotal: {1}, tax: {2}, total: {3}", ++count, subtotal, tax, total); //increments count
            } while (amount != -1);



        }
    }
}
