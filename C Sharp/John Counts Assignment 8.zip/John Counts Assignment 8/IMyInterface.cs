﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Assignment_8
{
    internal interface IMyInterface
    {
        string iMessage();
    }
}
