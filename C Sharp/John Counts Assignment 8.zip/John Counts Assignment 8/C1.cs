﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Assignment_8
{
    internal class C1 : IMyInterface
    {
        private double loanAmount = 0.0;
        private double years = 0.0;
        private double interests = 0.0;
        private double interestRate = 0.0;
        public double LoanAmount { get; set; }
        public double Years { get; set; }
        public double Interests { get; set; }
        public double InterestRate { get; set; }

        public C1(double loanAmt, double yrs, double intRate)
        {
            LoanAmount = loanAmt;
            Years = yrs;
            InterestRate = intRate;
        }

        public double PayInterests()
        {
            Interests = LoanAmount * InterestRate * Years;
            return Interests;
        }

        public string iMessage()
        {
            return "Be Ready!";
        }

    }
}
