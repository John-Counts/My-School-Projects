﻿namespace John_Counts_Assignment_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("please enter now the loan amount, number of years, and the interest rate below.");
            Console.WriteLine("loan amount:");
            double loanAmount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("years:");
            double years = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("interest rate (remember to put this in a decimal, eg- 1% is '0.01'):");
            double interestRate = Convert.ToDouble(Console.ReadLine());

            C1 c1 = new C1(loanAmount, years, interestRate);
            c1.iMessage();
            Console.WriteLine("amount in interest is: {0}", c1.PayInterests());
        }
    }
}
