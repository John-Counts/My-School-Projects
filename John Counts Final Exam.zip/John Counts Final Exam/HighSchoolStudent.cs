﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Final_Exam
{
    internal class HighSchoolStudent: Student, IMathClass
    {
        public HighSchoolStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID) { }
        public override string ImportantThing()
        {
            return "SAT exam.";
        }
        public string Math()
        {
            return "Basic Algebra.";
        }
        public override string ToString()
        {
            return "My name is " + FirstName + LastName + ", I am a High " +
                "school student. I will take the " + ImportantThing() + " I will learn "
                + Math();
        }
    }
}
