﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Final_Exam
{
    internal class CollegeStudent: Student, IMathClass
    {
        public CollegeStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID) { }
        public override string ImportantThing()
        {
            return "Major.";
        }
        public string Math()
        {
            return "Advanced Algebra.";
        }
        public override string ToString()
        {
            return "My name is " + FirstName + LastName + ", I am a College " +
                "student. I have a " + ImportantThing() + " I will learn "
                + Math();
        }
    }
}
