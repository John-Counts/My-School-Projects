﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Final_Exam
{
    internal class MiddleSchoolStudent : Student, IMathClass
    {
        public MiddleSchoolStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID) { }
        public override string ImportantThing()
        {
            return "Summer Camp!";
        }
        public string Math()
        {
            return "Geometry.";
        }
        public override string ToString()
        {
            return "My name is " + FirstName + LastName + ", I am a Middle " +
                "school student. I will have a " + ImportantThing() + " I will learn "
                + Math();
        }
    }
}
