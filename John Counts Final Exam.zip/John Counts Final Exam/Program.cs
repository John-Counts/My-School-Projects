﻿namespace John_Counts_Final_Exam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student[] students = new Student[4];
            students[0] = new ElementarySchoolStudent("timmy", "Smith", "123");
            students[1] = new MiddleSchoolStudent("Sally", "Hemsworth", "456");
            students[2] = new HighSchoolStudent("Warren", "Richardson", "789");
            students[3] = new CollegeStudent("Brian", "Geselschaftenburgermeisterfeldkriegoffsonsdottir", "012");

            foreach (var student in students) {Console.WriteLine(student.ToString());}
        }
    }
}
