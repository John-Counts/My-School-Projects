﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Final_Exam
{
    internal abstract class Student
    {
        public string firstName;    //instructions say to make data members public, but these are usually private, with properties being public
        public readonly string lastName;
        public readonly string studentID;
        public string FirstName { get; set; }     //readonly gives error -is not valid here: making data member readonly instead
        public string LastName { get; set; }
        public string StudentID { get; set; }
        public abstract string ImportantThing();
        public Student(string firstName, string lastName, string studentID)
        {
            FirstName = firstName;
            LastName = lastName;
            StudentID = studentID;
        }

    }
}
