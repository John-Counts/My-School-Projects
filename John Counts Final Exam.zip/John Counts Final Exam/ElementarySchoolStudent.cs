﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Final_Exam
{
    internal class ElementarySchoolStudent : Student, IMathClass
    {
        public ElementarySchoolStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID) { }

        public override string ImportantThing()
        {
            return "Farm field trip!";
        }
        public string Math()
        {
            return "Basic Math.";
        }
        public override string ToString()
        {
            return "My name is " + FirstName + LastName + ", I am an Elementary " +
                "school student. I will have an exciting " + ImportantThing() + " I will learn "
                + Math();
        }
    }
}
