﻿using System.Text.RegularExpressions;

namespace John_Counts_Assignment_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string names = "";
            string cardNum = "";
            
            string patternName = @"^[a-zA-Z]{2,15}\s[a-zA-Z]{2,15}$";
            Console.WriteLine("Please enter your first and last name, separated by a space:");
            names = Console.ReadLine();
            if (Regex.IsMatch(names, patternName))
            {
                Console.WriteLine("{0} follows the pattern", names);
            }
            else
            {
                Console.WriteLine("{0} does not follow the pattern", names);
            }
            


            string patternCard = @"^[0-9]{12,19}$";
            Console.WriteLine("Please enter a credit card number:");
            cardNum = Console.ReadLine();
            if (Regex.IsMatch(cardNum, patternCard))
            {
                Console.WriteLine("{0} follows the pattern", cardNum);
            }
            else
            {
                Console.WriteLine("{0} does not follow the pattern", cardNum);
            }


        }
    }
}
