﻿namespace John_Counts_Exam_1
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            Random randomNum = new Random();
            Single a = randomNum.NextSingle() * 100; //multiplies by 100 to get a value with 2 digits on left side of decimal
            Console.WriteLine(Math.Round(a, 2)); //rounds to 2 decimal places, producing an end result of a random number with formatting xx.xx

        }
    }
}
