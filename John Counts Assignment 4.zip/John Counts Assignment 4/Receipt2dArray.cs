﻿namespace John_Counts_Assignment_4
{
    internal class Receipt2dArray
    {
        static void Main(string[] args)
        {
            int i = 0;
            int j = 0;
            decimal total = 0.00m;
            int count = 0;
            string[,] items = new string[100, 4];
            do
            {
                Console.Write("Please enter the name of the next item (enter \"0\" if no more items to enter):");
                items[count, 0] = Console.ReadLine();
                if (items[count, 0] != "0")
                {
                    Console.Write("Please enter the price of the item:");
                    items[count, 1] = Console.ReadLine();
                    Console.Write("Please enter how many of such items:");
                    items[count, 2] = Console.ReadLine();
                    items[count, 3] = Convert.ToString(Convert.ToDecimal(items[count, 1]) * Convert.ToInt64(items[count, 2]));
                    Console.WriteLine("subtotal for item {0} entry:\t{1}", count + 1, items[count, 3]);
                    count++;
                }
            }

            while (items[count, 0] != "0");
            
            Console.WriteLine("Receipt generated:\n\n\n\n\t\tItem Name\tItem Price\tItem quantity\tsubtotal\n");
            for (i = 0; i < count; i++)
            {
                for (j = 0; j <= 3; j++)
                {
                    Console.Write("\t\t{0}", items[i, j]);
                }
                Console.WriteLine();
                //Console.WriteLine("\t\t{0}\t\t{1}\t\t{2}\t\t{3}", items[i, 0], items[i, 1], items[i, 2], items[i, 3]);
                total = total + Convert.ToDecimal(items[i, 3]);

            }
            Console.WriteLine("\t\t*********************************************************");
            Console.WriteLine("\t\t\ttotal for receipt is:\t\t\t{0}", total);

        }
    }
}
