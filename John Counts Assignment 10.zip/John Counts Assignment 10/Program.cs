﻿namespace John_Counts_Assignment_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("this program will create a string list; " +
                "collect values for the list of firstName, lastName, street, city, " +
                "state, zip; will change the values to upper case; and will display the " +
                "list with a foreach statement.");

            List<string> ucItems = new List<string>();
            Console.WriteLine("please enter first name:");
            ucItems.Add(Console.ReadLine());
            Console.WriteLine("please enter last name:");
            ucItems.Add(Console.ReadLine());
            Console.WriteLine("please enter street:");
            ucItems.Add(Console.ReadLine());
            Console.WriteLine("please enter city:");
            ucItems.Add(Console.ReadLine());
            Console.WriteLine("please enter state:");
            ucItems.Add(Console.ReadLine());
            Console.WriteLine("please enter zip code:");
            ucItems.Add(Console.ReadLine());

            
            var makeUpper =
                from uc in ucItems
                let ucstring = UppercaseWords(uc)
                select ucstring;

            foreach (var item in makeUpper)
            {
                Console.Write("{0} ", item);
            }
        }

        public static string UppercaseWords(string value)
        {
            char[] array = value.ToCharArray();

            if (array.Length >= 1)
            {
                if (char.IsLower(array[0]))
                {
                    array[0] = char.ToUpper(array[0]);
                }
            }

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] == ' ')
                {
                    if (char.IsLower(array[i]))
                    {
                        array[i] = char.ToUpper(array[i]);
                    }
                }
            }
            return new string(array);
        }
    }
}
