﻿using System.Collections;

namespace John_Counts_Assignment_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool aBoolean = true;
            char aCharacter = '$';
            int anInteger = 34567;
            string aString = "hello";
            Queue queue = new Queue();
            queue.Enqueue(aBoolean);
            queue.Enqueue(aCharacter);
            queue.Enqueue(anInteger);
            queue.Enqueue(aString);

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("i is {0}", i);
                Console.WriteLine("Peek next to dequeue: {0}", queue.Peek());
                Console.WriteLine("Dequeue '{0}'", queue.Dequeue());
            }
        }
    }
}
