﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Exam_2
{
    internal class Person
    {
        private int age;
        private string name;
        private int yearsToWork;
        public int Age { get { return age; } set {  age = value; } }
        public string Name { get { return name; } set { name = value; } }
        public int YearsToWork 
        { 
            get 
            {
                YTK();
                return yearsToWork; 
            } 
        } 
        private void YTK()
        {
            yearsToWork = 65 - Age;
        }


    }
}
