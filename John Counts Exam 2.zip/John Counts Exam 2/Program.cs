﻿namespace John_Counts_Exam_2
{
    internal class PersonRun
    {
        static void Main(string[] args)
        {
            Console.WriteLine("greetings, this program will tell you how many years you will need to work yet before retirement.");
            Console.WriteLine("Please type your name.");
            Person Prs = new Person();
            Prs.Name = Console.ReadLine();
            Console.WriteLine("hello, {0}, please enter your age.", Prs.Name);
            Prs.Age = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("{0}, of {1} years, it would appear you need to work {2} years until retirement.", Prs.Name, Prs.Age, Prs.YearsToWork);
        }
    }
}
