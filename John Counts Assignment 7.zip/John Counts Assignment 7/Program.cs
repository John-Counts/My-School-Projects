﻿namespace John_Counts_Assignment_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Campus atc = new Campus("Advanced Technology College");

            Console.WriteLine(atc.ToString());
        }
    }
}
