﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace John_Counts_Assignment_7
{
    internal class DSC
    {
        private string schoolName;
        public string SchoolName { get; set; }
        public DSC()
        {
            SchoolName = "Daytona State College";
        }
        public virtual string ShowAddress()
        {
            return "1200 W. International Speedway Blvd., Daytona Beach, Florida 32114";
        }
    }
}
