﻿namespace John_Counts_Assignment_1._2
{
    internal class CalculatorIf
    {
        static void Main(string[] args)
        {
            double firstOperand;
            double secondOperand;
            double result;
            string oprt;
            Console.WriteLine("This Program will do one calculation using the numbers and operation you input.");
            Console.WriteLine("To begin, please enter the first operand.");
            firstOperand = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("now, please enter the operation you would like, as a standard symbol. (-, +, *, or /)");
            oprt = Console.ReadLine();
            Console.WriteLine("now, please enter the second operand.");
            secondOperand = Convert.ToDouble(Console.ReadLine());

            if (oprt == "+")
            {
                Console.WriteLine("Addition: {0} + {1} = {2}", firstOperand, secondOperand, result = firstOperand + secondOperand);
            }
            else if (oprt == "-")
            {
                Console.WriteLine("Subtraction: {0} - {1} = {2}", firstOperand, secondOperand, result = firstOperand - secondOperand);
            }
            else if (oprt == "*")
            {
                Console.WriteLine("Multiplication: {0} * {1} = {2}", firstOperand, secondOperand, result = firstOperand * secondOperand);
            }
            else if (oprt == "/")
            {
                Console.WriteLine("Division: {0} / {1} = {2}", firstOperand, secondOperand, result = firstOperand / secondOperand);
            }
            else
            {
                Console.WriteLine("I'm sorry, but you did not feel like math today, so no math has been done.");

            }

        }
    }
}
